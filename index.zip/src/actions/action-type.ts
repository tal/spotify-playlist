export type ActionType = 'positive' | 'negative'
