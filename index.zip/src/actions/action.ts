import { ActableType, currentlyPlayingActableType } from './actionable-type'
import { Spotify } from '../spotify'
import { ActionType } from './action-type'

export abstract class Action {
  static types: ActableType[]
  static action: ActionType

  async handle(action: ActionType, client: Spotify) {
    const type = await currentlyPlayingActableType(client)
    if (!this.matchesActionable(type)) return
    if (!this.matchesAction(action)) return

    return this.perform(client)
  }

  get statik() {
    return this.constructor as typeof Action
  }

  matchesActionable(type: ActableType) {
    return this.statik.types.includes(type)
  }

  matchesAction(type: ActionType) {
    return type == this.statik.action
  }

  protected abstract perform(client: Spotify): Promise<void>
}
