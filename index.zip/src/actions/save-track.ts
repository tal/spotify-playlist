import { Action } from './action'
import { ActableType } from './actionable-type'
import { Spotify } from '../spotify'
import { ActionType } from './action-type'

export class SaveTrack extends Action {
  static types: ActableType[] = ['triage_source']
  static action: ActionType = 'positive'

  async perform(client: Spotify) {
    const track = await client.currentTrack

    if (!track) return

    client.saveTrack(track.id)
  }
}
