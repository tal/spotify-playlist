import { Spotify } from './spotify'
import { document } from './db/document'
import { ensuareAllTablesCreated } from './db/table-definition'

export async function settings() {
  return {
    inbox: 'Inbox',
    current: 'Current',
  }
}

async function main() {
  await ensuareAllTablesCreated()
  const u = await document('user', { id: 'koalemos' })

  if (u) {
    const spotify = await Spotify.get(u)
    const player = await spotify.player
    console.log(player.context)
  }
}

if (require.main === module) {
  main().catch(err => {
    console.error(err)
  })
}
